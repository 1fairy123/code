clc
clear
data=xlsread('severe_GEM.xlsx');
alpha=0.1;
boxsize=0.1;
weighted=1;
c = [];
kk=1;

cndm = condition_ndm(data,alpha,boxsize,kk);
xlswrite('severe_CNDM.xlsx',cndm);
ccsn = csnet(data,c,alpha,boxsize,weighted);



