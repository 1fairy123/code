clear
data=xlsread('severe_GEM.xlsx');
alpha=0.2;
boxsize=1.5;
weighted=1;
c = [];
kk=1;
ccsn= csnet(data,c,alpha,boxsize,kk,weighted);

data = zeros(14900);
for i = 1:length(ccsn)
    tmp = ccsn{1,i};
    data = data + tmp;    
end
avr = data/length(ccsn);

fid = fopen('severe_avr.txt','wt');
[m,n] = size(avr);
for i = 1:1:m
for j = 1:1:n
   if j == n
      fprintf(fid,'%g\n',avr(i,j));
   else 
      fprintf (fid,'%g\t',avr(i,j));
   end
end
end
fclose(fid);