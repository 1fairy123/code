rm(list=ls())
library(survival)
library(survminer)
library(survival)
library(survminer)
library(stringr)

setwd("F:\\liying\\prognosis\\degree")
exprSet<- read.csv('Survival_analysis_CNDM.csv',header=T,row.names = 1,check.names=FALSE)
surv = read.table("TCGA-LUAD.survival.tsv",header = T)
meta=surv
colnames(meta)=c('SAMPLE','event','ID','time')
meta=meta[match(str_sub(colnames(exprSet),1,12),meta$ID),]
identical(meta$ID,str_sub(colnames(exprSet),1,12))

library(survival)
library(survminer)
logrankfile = paste0(cancer_type,"_log_rank_p.Rdata")
if(!file.exists(logrankfile)){
  log_rank_p <- apply(exprSet , 1 , function(gene) {
    #gene=exprSet[1,]
    meta$group=ifelse(gene>median(gene),'high','low')
    data.survdiff=survdiff(Surv(time, event)~group,data=meta)
    p.val = 1 - pchisq(data.survdiff$chisq, length(data.survdiff$n) - 1)
    return(p.val)
  })
  log_rank_p=sort(log_rank_p)
  save(log_rank_p,file = logrankfile)
}

lr = names(log_rank_p)[log_rank_p<0.05];length(lr)
lr <- as.data.frame(lr)
write.csv(lr,file = "CNDM_p_value_less_than_0.05.csv")

