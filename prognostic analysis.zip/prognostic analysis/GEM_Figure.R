rm(list=ls())
setwd("F:\\liying\\预后\\最新版预后\\基因表达矩阵")
load("跑生存分析的gene表达cpm.Rdata")
#exprSet<-data.table::fread("重LUADCPM度矩阵.csv")
#exprSet111111<- read.csv('24gene表达.csv',header=T,row.names = 1,check.names=FALSE)
#exprSet<-as.matrix(exprSet1)
#class(exprSet)
surv = read.table("TCGA-LUAD.survival.tsv",header = T)
meta=surv
colnames(meta)=c('SAMPLE','event','ID','time')
library(stringr)
#调整meta的ID顺序与exprSet列名一致
meta=meta[match(str_sub(colnames(exprSet),1,12),meta$ID),]
identical(meta$ID,str_sub(colnames(exprSet),1,12))

library(survival)
library(survminer)
genenames<- read.csv('基因表达P值大.csv',header=T,row.names = 1,check.names=FALSE)

gs=rownames(genenames)[1]
for (i in gs){
  splots <- lapply(gs, function(g){
    meta$gene=ifelse(exprSet[g,] > median(exprSet[g,]),'high','low')
    sfit1=survfit(Surv(time, event)~gene, data=meta)
    ggsurvplot(sfit1,pval =TRUE, data = meta, 
               ggtheme = theme_classic2(),#生存曲线图的主题
               xlab = "Time（Days）",
               legend="top", #指定图例的位置
               legend.title = paste(i,"Expression",sep="_"), #指定图例组的名字
               legend.labs = c("HighGroup","LowGroup"), #指定图例标签的字符向量
               risk.table = TRUE)
  }) 
  res<-arrange_ggsurvplots(splots, print = F,  
                           ncol = 1, nrow = 1, risk.table.height = 0.25)
  #ggsave(paste(i,"Expression_surv.png",sep = "_"), res,width=7,height = 6)
  ggsave(paste(i,"degree_surv.pdf",sep = "_"), res,width=7,height = 6)
}

